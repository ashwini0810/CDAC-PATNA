package org.fi.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Program {

	public static void main(String[] args) {
		
				
		// TODO Auto-generated method stub
		Connection connection = null;
		Statement stSelect = null;
		ResultSet result = null;
		
try {
			
			//2.load a driver using which i will connect to the database
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//3.connect to the database
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaee_0005","root","admin@123");
			
			//4.allocate statement 
			stSelect=connection.createStatement();
			
			//5.fire the query and generate the result
			result=stSelect.executeQuery("select * from user_0005");
			
			while(result.next())
			{
				System.out.println(result.getString(1));
				System.out.println(result.getString(2));
				System.out.println(result.getString(3));
				System.out.println(result.getString(4));
				System.out.println("---------------------------------------");

			}
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			//6.release all the resources
			try {
				if(result!=null)
					result.close();
				if(stSelect!=null)
					stSelect.close();
				if(connection!=null)
				    connection.close();
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
        
	}



		
		

	}