package org.fi.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection = null;
		Statement stInsert = null;
		Scanner scanner = null;
		
try {
			
			//2.load a driver using which i will connect to the database
			Class.forName("com.mysql.cj.jdbc.Driver");
			scanner =new Scanner(System.in);
			//3.connect to the database
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaee_0005","root","admin@123");
			
			//4.allocate statement 
			stInsert=connection.createStatement();
			
			//5.fire the query and generate the result
			System.out.println("Enter the username");
			String username = scanner.next();
			System.out.println("Enter the password");
			String password = scanner.next();
			System.out.println("Enter the mobile");
			String mobile = scanner.next();
			System.out.println("Enter the age");
			int age = scanner.nextInt();
			String sqlInsert =" insert into user_0005 values('"+username+"','"+password+"''"+mobile+"','"+age+"')";
			System.out.println("SQL : "+sqlInsert);
			int rows = stInsert.executeUpdate(sqlInsert);
			if(rows>0)
				System.out.println("Record saved");
			else
			System.out.println("Unable to saved");
}catch (ClassNotFoundException e) {
	e.printStackTrace();
	}catch(SQLException e) {
		e.printStackTrace();
		}
finally
{
	try {
		if(scanner!=null)
			scanner.close();
		if(stInsert!=null)
			stInsert.close();
		if(connection!=null)
		    connection.close();
		
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}

}

	}


